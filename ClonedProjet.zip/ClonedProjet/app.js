import express from "express";
import bodyParser from "body-parser";
import pg from "pg";
import bcrypt from "bcrypt";
import session from "express-session";
import passport from "passport";
import { Strategy } from "passport-local";

const app = express(); // server created
const port = 3000; // port created
const saltRounds = 10;

const db = new pg.Client({ // db obj created
    user: "postgres",
    host: "localhost",
    database:"permalist",
    password: "12345",
    port: 5432,
});
db.connect(); // database connected
// create session sign cookie
app.use(
    session({
        secret: "toDoList",
        resave: false,
        saveUninitialized: true,
    })
);

app.use(bodyParser.urlencoded({extended: true})); // read ejs form data
app.use(express.static("public")); // interduce our files path to server

app.use(passport.initialize());
app.use(passport.session());

let items = [
    {id: 1, title: "Array to do List"},
    {id: 2, title: "Database is down"},
]; // array incase database do not work

app.get("/dashboard", async (req, res) => {
  if (req.isAuthenticated()) {
    try {
      const result = await db.query("SELECT * FROM items ORDER BY id ASC");
      res.render("index.ejs", { listTitle: "To Do List", listItems: result.rows, });
    } catch (err) { console.log(err);}
  } else { res.redirect("/login");}
});
// new code
app.get("/", async (req, res)=>{
    try{
       
        res.render("home.ejs");
    } catch (err){console.log(err);}
});
app.get("/register", async (req, res)=>{
    try{
       
        res.render("register.ejs");
    } catch (err){console.log(err);}
});
app.get("/login", async (req, res)=>{
    try{
       
        res.render("login.ejs");
    } catch (err){console.log(err);}
});
app.get("/logout", async (req, res)=>{
    try{
       
        res.render("home.ejs");
    } catch (err){console.log(err);}
});

// adding bcrypt

app.post("/register", async (req, res) => {
    const email = req.body.username;
    const password = req.body.password;
 try{
  const checkResult = await db.query("Select * from users where email = $1", [email]);
  if(checkResult.rows.length>0){
    res.send("Email Already exists.");
  }else{ 
    // hashing the password
    bcrypt.hash(password, saltRounds, async(err, hash)=>{
        if(err){
            console.error("Error hashing password:", err)
        }
        else{
            console.log("hashing Password:", hash)
               const result = await db.query("INSERT INTO users (email, password) VALUES ($1, $2) ", [email, hash]);
                 console.log(result);
                 res.redirect("/dashboard");
        }
    })
    }
  }catch (err){console.log(err);};
});

app.post("/login",
    passport.authenticate("local",{
        successRedirect: "/dashboard",
        failureRedirect: "/login",
    })
);
// new code ended

app.post("/add", async (req, res)=>{
    const item = req.body.newItem;
    try{
        await db.query("INSERT INTO items (title) VALUES ($1)",[item]);
        res.redirect("/dashboard");
    } catch (err){console.log(err);}
});
app.post("/edit", async (req, res)=>{
    const item = req.body.updatedItemTitle;
    const id = req.body.updatedItemId;
    try{
        await db.query("UPDATE items SET title = $1 WHERE id = $2 ", [item, id]);
        res.redirect("/dashboard");
    } catch (err){console.log(err);}
});
app.post("/delete", async (req, res)=>{
    const id = req.body.deleteItemId;
    try{
        await db.query("DELETE FROM items WHERE id = $1 ", [id]);
        res.redirect("/dashboard");
    } catch (err){console.log(err);}
});

// create locat strategy
passport.use(
  new Strategy(async function verify(username, password, cb) {
    try {
      const result = await db.query(
        "SELECT * FROM users WHERE email = $1",
        [username]
      );

      if (result.rows.length > 0) {
        const user = result.rows[0];
        const storedHash = user.password;

        bcrypt.compare(password, storedHash, (err, isMatch) => {
          if (err) {
            return cb(err);
          }

          if (isMatch) {
            return cb(null, user); // ✅ SUCCESS
          } else {
            return cb(null, false); // ❌ WRONG PASSWORD
          }
        });
      } else {
        return cb(null, false); // ❌ USER NOT FOUND
      }
    } catch (err) {
      return cb(err);
    }
  })
);
passport.serializeUser((user, cb)=>{
    cb(null, user);
});
passport.deserializeUser((user, cb)=>{
    cb(null, user);
});
app.listen(port, ()=>{
    console.log(`Server is running on port ${port}`);
})